<?php

//重定向浏览器 
header("Location: https://act.mogujie.com/lqxhh?userid=13a3kyq&gid=390");
//确保重定向后，后续代码不会被执行 
exit;
