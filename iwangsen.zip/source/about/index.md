---
title: 关于我
date: 2018-04-27 14:42:00
tags: [me]
---

Name

	CN: 王森  | 花名: 大和

I Am

	一名喜欢技术但是技术很渣的工程师。


Contact

	微博：霸气的王先森

	Gmail: 724wangsen#gmail.com

	OtherEmail：wangsen724#foxmail.com

#替换为@
