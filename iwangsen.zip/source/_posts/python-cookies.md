---
title: Python3获取Cookies
date: 2018-05-30 14:24:27
tags: [python,cookies]
---
直接上代码

```bash
from http import cookiejar
import urllib.request

cookie = cookiejar.CookieJar()
handler = urllib.request.HTTPCookieProcessor(cookiejar=cookie)
opener = urllib.request.build_opener(handler)

response = opener.open('http://www.baidu.com')
for item in cookie:
    print(item.name+'='+item.value)

```

run后应该可以看到捕获的Cookies
内容不一定一致
```bash
BAIDUID=59D5A393EE862642C4A78AA8FC896987:FG=1
BIDUPSID=59D5A393EE862642C4A78AA8FC896987
H_PS_PSSID=1426_21123_18559_20928
PSTM=1527661569
BDSVRTM=0
BD_HOME=0

```
