---
title: Centos7升级Python到3之后yum报错,以SVN搭建举例
date: 2018-06-05 10:16:10
tags: [centos,python]
---

我升级了Python到3.6,然后使用yum安装会报语法错误，python2和3的语法并不兼容，OK，我们来机智的解决一下这个问题

前提是没有彻底删掉自带旧的python2.7的话。如果已经删掉，那么需要重新安装新的yum

比如我现在在自建SVN的server端

```bash
yum install subversion -y
```
因为我默认的python环境变量是3.6,所以会报错

![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-update-yum.png)

修改yum运行的python为2.7

```bash
vi /usr/bin/yum

#!/usr/bin/python2.7
```
继续安装


所依赖的libexec也有python版本问题，继续解决它

```bash
vi /usr/libexec/urlgrabber-ext-down

#! /usr/bin/python2.7
```
![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-update-yum-2.png)

查看是否安装成功
![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-update-yum-3.png)


之后的SVN创建版本库、配置账密、设置权限等后续添加上

继续写

创建svn版本库目录
```bash
mkdir -p /opt/svn/repos
```

创建版本库

```bash
svnadmin create /opt/svn/repos
```

进入conf目录 /opt/svn/conf/

authz文件是权限控制文件

passwd是帐号密码文件

svnserve.conf SVN服务配置文件

设置帐号密码

```bash
vi passwd

在[users]块中添加用户和密码，格式：帐号=密码，如wangsen=wangsen
```

设置权限

```bash
vi authz

在末尾添加如下代码：

[/]
wangsen=rw
wagnshitou=r
```

意思是版本库的根目录wangsen对其有读写权限，wangshitou只有读权限



修改svnserve.conf文件

```bash
vi svnserve.conf

打开下面的几个注释：

anon-access = read #匿名用户可读

auth-access = write #授权用户可写

password-db = passwd #使用哪个文件作为账号文件

authz-db = authz #使用哪个文件作为权限文件

realm = /opt/svn/repos # 认证空间名，版本库所在目录
```

启动svn版本库

```bash
svnserve -d -r /opt/svn/repos
```

SVN默认的打开端口是3690
可以通过下面的命令查看：
```bash
netstat -antp | grep svn

tcp        0      0 0.0.0.0:3690            0.0.0.0:*               LISTEN      66486/svnserve 
```

centos7 打开防火墙端口

```bash
sudo firewall-cmd --permanent --add-port=3690/tcp
sudo firewall-cmd --reload
```


最后在本地checkout就OK了
svn://your IP


这可能是我最后一次弄SVN的东西了，好多年都不用，github使用起来更方便也很友好
