---
title: go语言操作excel文件
date: 2018-06-02 20:48:55
tags: [go]
---

Excelize 是 Go 语言编写的一个用来操作 Office Excel 文档类库，基于 ECMA-376 Office OpenXML 标准。可以使用它来读取、写入 XLSX 文件。相比较其他的开源类库，Excelize 支持写入原本带有图片(表)的文档，还支持向 Excel 中插入图片，并且在保存后不会丢失图表样式。

安装

```bash
go get github.com/360EntSecGroup-Skylar/excelize
```

![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/go-excel.png)


读取已有文档

```bash
package main

import "fmt"
import "github.com/360EntSecGroup-Skylar/excelize"

func main() {
	xlsx, err := excelize.OpenFile("./这是一个文字马赛克用来隐藏我真实的文件名称.xlsx")
	if err != nil {
		fmt.Println(err)
		return
	}
	// Get all the rows in the Sheet1.
	rows := xlsx.GetRows("Sheet1")
	for _, row := range rows {
		for _, colCell := range row {
			fmt.Print(colCell, "\t")
		}
		fmt.Println()
	}
}

```

run后会展示出表格中的sheet1信息

![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/go-excel2.png)



接下来还有其他用法，持续更新中，会贴出经过测试的实战代码

参考源地址https://blog.csdn.net/mrxuri/article/details/53842834
