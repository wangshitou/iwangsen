---
title: 有趣的一行python代码
date: 2018-05-31 16:57:39
tags: [python]
---

Python 这门语言非常的有趣，不仅可以做高大上的人工智能、大数据、机器学习。还可以用来做 web、爬虫。还有其它很多的应用。今天我就给大家展示下一行 python 代码都可以做些什么。

* 一行打印迷宫

```bash
print(''.join(__import__('random').choice('\u2571\u2572') for i in range(50*24)))
```

上述代码若无法打印迷宫，可以用下面的代码实现：


```bash
print(''.join(__import__('random').choice('/\\') for i in range(50*24)))
```


![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-migong.png)





* 一行打印桃心

```bash
print('\n'.join([''.join([('AndyLove'[(x-y)%8]if((x*0.05)**2+(y*0.1)**2-1)**3-(x*0.05)**2*(y*0.1)**3<=0 else' ')for x in range(-30,30)])for y in range(15,-15,-1)]))
```


![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-taoxin.png)



* 一行输出九九乘法表

```bash
print ('\n'.join([' '.join(['%s*%s=%-2s' % (y,x,x*y) for y in range(1,x+1)]) for x in range(1,10)]))
```


![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-99chengfa.png)




* 一行代码画 Mandelbrot

```bash
print('\n'.join([''.join(['*'if abs((lambda a:lambda z,c,n:a(a,z,c,n))(lambda s,z,c,n:z if n==0else s(s,z*z+c,c,n-1))(0,0.02*x+0.05j*y,40))<2 else' 'for x in range(-80,20)])for y in range(-20,20)]))
```


![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-Mandelbrot.png)




原文转载自公众号链接https://mp.weixin.qq.com/s/o9rm4tKsJeEWyqQDgVEQiQ
