---
title: Nginx过滤恶意爬虫
date: 2018-05-03 12:15:01
tags: [nginx,爬虫]
---

因为python编程语言的火热，导致爬虫越来越多，

这些爬虫不同于搜索引擎的爬虫蜘蛛，它们像是刚出生的蜘蛛，一点也不智能，不知道如何控制自己的力道，哐哐就是爬，消耗了很多服务器的硬件资源。占用了正常用户的访问需求。

接下来就用一个很简单的方法来防止这种事情的发生

利用来者访问的UA可以很方便的过滤恶意请求。

在nginx的URL入口位置写一个正则匹配出来恶意的UA，然后pass掉它就OK了


修改nginx的conf文件为

```bash
''''
    location / {
        if ($http_user_agent ~* "python|curl|java|wget|httpclient|okhttp") {
            return 503;
        }
        # 正常处理的逻辑段落
        ''''''''''
    }
''''
```

变量$http_user_agent是一个可以直接在location中引用的Nginx变量。~*表示不区分大小写的正则匹配，通过python就可以过滤掉80%的Python爬虫。

举一反三，这个方式也可以用来过滤搜索引擎的爬虫蜘蛛，比如我们的网站不想让搜索引擎收录，或者是线上仿真环境，不想提前曝光，我们有两种方式禁止搜索引擎的蜘蛛

1. 通过访问禁止的方式:

识别来访问的是否为搜索引擎的蜘蛛爬虫，如果是则返回503。

```bash
''''
    location / {
        if ($http_user_agent ~* "qihoobot|Baiduspider|Googlebot|Googlebot-Mobile|Googlebot-Image|Mediapartners-Google|Adsbot-Google|Feedfetcher-Google|Yahoo! Slurp|Yahoo! Slurp China|YoudaoBot|Sosospider|Sogou spider|Sogou web spider|MSNBot|ia_archiver|Tomato Bot") {
            return 503;
        }
        # 正常处理的逻辑段落
        ''''''''''
    }
''''
```
2. 通过Robots.txt来限制爬虫的收录

robots.txt是国际通用的准则，规定了网站上的什么文件是可以查看的，什么文件是不可以查看的，只是它是道德层面的，如果搜索引擎的蜘蛛想要获取数据还是会拿到的





