---
title: Laravel自带Auth登陆后的跳转
date: 2018-05-05 11:30:11
tags: [laravel , PHP]
---

Laravel自带的 Auth登陆验证,在登陆或注册成功后，会跳转到 /home, 但是我的项目不想用home。而且同一个框架分了前后台。不想让访问home。

所以我们需要修改这个默认的跳转

在Controllers\Auth目录下，修改LoginController.php、RegisterController.php、ResetPasswordController.php这三个文件，

其中

```bash
protected $redirectTo = '/home'; //修改为自己想要的路径

```

另外还需要解决session验证跳转的路径问题

在Middleware目录下，修改RedirectlfAuthenticated.php文件，

其中

```bash
if (Auth::guard($guard)->check()) {
    return redirect('/home');
}

```

修改为

```bash
if (Auth::guard($guard)->check()) {
    return redirect('/'); //这儿改为自己想要的路径
}
```


