---
title: php中foreach批量进行curl请求
date: 2018-05-24 12:21:15
tags: [PHP]
---

# 方法一

```bash
$array = array(url_1,url_2,url_3);
foreach ($arrayr as $k=>$v) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $v);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
	$output = curl_exec($ch);
	$httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	echo $output;
}
curl_close($ch); 
```

最基础的方法，循环中对每个URL进行提取。较为耗时，如果数据量过大，需要注意PHP的超时时间和占用内存大小设置的较大一点。


# 方法二

稍后加上
