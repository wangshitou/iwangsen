---
title: php7的excel导出
date: 2018-05-24 17:44:59
tags: [php,excel]
---

一直在用PHPExcel做php操作excel表格的导入导出。php5版本的没有任何问题，今天源代码迁移到php7环境，发现报错

解决办法：
修改PHPExcel插件源码
PHPExcel/Calculation/Functions.php

删除或者注释掉这个break就OK了

![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/php7-excel.jpg)

