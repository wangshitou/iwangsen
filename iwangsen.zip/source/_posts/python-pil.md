---
title: windows下Python安装PIL图像处理库
date: 2018-05-25 12:14:58
tags: [python,pil]
---

保险起见先检测一下自己是否安装了pip
安装python一般自带这个

![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-pil-3.png)

也可以使用此命令来安装
```bash
pip install PIL 
```

PIL官方网站提供的PIL都是32位的，如果你的电脑是64位的或者你想自己安装PIL，那么往下看

https://www.lfd.uci.edu/~gohlke/pythonlibs/#pillow
在PIL非官方库下载非官方的pillow，注意下载符合自己的python版本的。我是python3.6，下载的如图所示

![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-pil.png)

下载完成之后，进入pip目录，进行安装，命令是pip install 下载的pillow路径，比如我的如图所示，我下载到桌面上了

![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-pil-4.png)

安装完成之后，检测一下是否安装成功，在代码中引入一下看是否报错

from PIL import Image

![Aarron Swartz](https://raw.githubusercontent.com/wangshitou/iwangsen/master/img/python-pil-2.png)

OK,bingo ^_^
