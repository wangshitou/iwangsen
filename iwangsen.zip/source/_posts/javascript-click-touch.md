---
title: Js中click、touch事件浅析
date: 2018-05-16 10:29:12
tags: [javascript]
---

在写模拟触发复制剪切板的功能，发现click和touch一些特性，记录一下

因为是脚本引用，没用jQuery、jqmobile、zepto,所以其它如tap等不做比较

1、click 和 touch 都会在点击的时候触发。

   也就是touch会重复调用click

   经过测试，click事件触发比touch事件晚一点。

2、touch事件在移动端的应用

touch 包括touchstart,touchmove,touchend,touchcancel 这四个事件

touchstart事件：当手指触摸屏幕时候触发，即使已经有一个手指放在屏幕上也会触发。
touchmove事件：当手指在屏幕上滑动的时候连续地触发。在这个事件发生期间，调用preventDefault()事件可以阻止滚动。
touchend事件：当手指从屏幕上离开的时候触发。
touchcancel事件：当系统停止跟踪触摸的时候触发。关于这个事件的确切出发时间，文档中并没有具体说明，咱们只能去猜测了。


这4个事件的触发顺序为：

touchstart -> touchmove->```````` -> touchmove ->touchend

3、监听的click和touch方法中，都写了模拟点击的代码，但是click触发之后，obj.click()是生效的。touch方法里面的obj.click()就不会生效

4、还在核实中... ...
